<?php

global $_MODULE;
$_MODULE = array();
$_MODULE['<{jqueryslider}prestashop>jqueryslider_783adb82646f4a797019b73ced824d17'] = 'JQuerySlider Galerie';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_087a9f1efef3990090d72543bbde9903'] = 'Image Rotator';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_07b8c09e490f7afbdcfa9cd5bfcfd4a9'] = 'Une erreur s\'est produite lors du téléchargement de l\'image.';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_ea83e4005a3edd639f663dc2d1bff0a3'] = 'Impossible d\'écrire dans le fichier de l\'éditeur.';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_8072bc856691062b88d30354ab28a27a'] = 'Impossible de fermer le fichier de l\'éditeur.';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_93314199c1f5be182040fd88370f44f4'] = 'Impossible de mettre à jour le fichier de l\'éditeur.rnS\'il vous plaît vérifier les autorisations d\'écriture du fichier de l\'éditeur.';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_9b838ba01e3eddffba8bb08a0c60513b'] = 'Votre dossier liens est vide.';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_e4916a309da758305c54885e3f5672a8'] = 'Aide';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_3c08211baf9550768bb30ea5be350fc1'] = 'Configuration: Vous pouvez entrer ici les images qui seront présentées dans le slider avec le lien correspondant pour chacun d\'eux.';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_560cea44c012319f3cc492467b4fcce2'] = 'Si vous voulez que cette section contienne plus d\'image à insérer modifier manuellement le fichier \"links.xml\".';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_17fceb82e60b532cbfbba27d42234a9e'] = 'Par défaut seulement 4 images peut être dans le slider.';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_fa17a41b4421ba336a111fc9c213bf74'] = 'Important: Toutes les images doivent avoir la même taille en largeur et en hauteur en pixels.';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_97abe74be964f6eb5b07a11f600decdc'] = 'Pour modifier la taille du conteneur de l\'image, vous devez éditer le fichier qui se trouve dans : \"modules/jqueryslider/css/jqueryslider.css\" et modifier les valeurs: width,height.';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_3288d13ca0a412a424345817f97092d6'] = 'La vitesse et autres paramètres peuvent être modifiés à partir du fichier: \"modules/jqueryslider/js/easySlider1.5.js\".';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_89503ae473cde8c41e6cd2ea298d3a3a'] = 'Ces changements ne seront effectués que pour la première fois, alors vous pouvez faire des changements sans avoir à éditer les images ci-dessus à nouveau les valeurs.';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_372950483aae6354b32f0bcf454a7b68'] = 'Slider #';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_85ba46406f3b791c4f77c4dc6da2cdb4'] = 'Image à 50%';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_4f4705d6f8dd8cadee5b8bf9584ccd66'] = 'Lien';
$_MODULE['<{jqueryslider}prestashop>jqueryslider_d3270bdb8d2c1caaca4178dbe19be03a'] = 'Enregistrer';
